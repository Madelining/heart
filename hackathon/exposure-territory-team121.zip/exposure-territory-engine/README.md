# Team121 — Exposure Territory Bot

目标：在 41×41、600 回合的“曝光领地”对局中，以安全的闭合扩张取得高净分，同时避免错误回复、撞缺陷、撞轮廓和无意义长线。

> 重要说明：当前工作区没有收到官方 `player-kit.zip`，因此这份工程按你提供的规则分析和 Python SDK 接口摘要实现。它不是“必胜保证”，也没有声称通过了官方引擎对战。接入正式材料包后，必须先跑下方的原生引擎验证，再提交比赛。

## 当前策略

1. **闭合优先**：在己方已有领地边界上枚举矩形闭合路线，计算被围区域的面值、抢占对手领地收益和露边扣分变化。
2. **路径严格按回合模拟**：路径搜索状态包含 `(x, y, dir)`；遵守“不能反向转向”和“起步格决定 1/2 步”的规则，避免规划出几何上连通、实际却走不过去的路线。
3. **加权评估**：对 `*` 按 3 分计，对夺取敌方格按净分差双倍收益估算，并估计露边成本、完成回合数和敌方到达轮廓的时间。
4. **有限候选集**：先做轻量收益筛选，再对少量高潜力候选计算精确局部露边变化，控制 200ms 回合时限风险。
5. **引擎一步安全检查**：如果 SDK 提供 `state.game.copy().step()`，对当前动作尝试多种敌方指令，过滤明显会立即报废的动作。
6. **回家兜底**：当前位于己方领地外时，优先按方向状态 BFS 寻找回到己方领地的安全路径。
7. **异常兜底**：`act()` 最外层捕获异常，始终返回合法方向字符。

## 目录

```text
exposure-territory-engine/
├── README.md
├── STRATEGY_DESIGN.md
├── bots/
│   └── team121_agent/
│       ├── __init__.py
│       └── strategy.py
└── tests/
    └── test_strategy_core.py
```

## 接入官方 player-kit

1. 解压官方 `player-kit.zip`，确认 `sdk/`、`engine/` 和 `bots/my_bot_python/` 存在。
2. 复制 `bots/team121_agent/strategy.py` 到官方 Python 模板目录中，替换模板的策略实现文件；**保留官方模板原有的 HTTP 服务入口、`bot.json`、README 和 SDK 文件**。不要用本工程自造入口覆盖官方通信层。
3. 确认官方入口按 `from strategy import Strategy`（或模板现有模块路径）加载类；若模板文件名不同，只调整 import，不改 `Strategy.__init__ / act / end` 接口。
4. 在 `player-kit` 目录执行：

```powershell
python -m unittest discover -s ..\exposure-territory-engine\tests -v
python -m engine team121 bot002 --seed 42
python -m engine bot002 team121 --seed 42
```

两边都必须达到 `600/600` 回合、0 错误。之后至少再测 30 个不同 seed，并记录胜局、平均分差、错误数、耗时分位数。

## 资源预算建议

官方每回合回复时限为 200ms。该策略将矩形起点限制在当前领地附近，并使用候选 shortlist；仍需在参赛机器上检查 `last_act_ms`（仅内部诊断字段）和实际裁判 `time_us`。任何一次接近 200ms 的结果都应继续收紧候选数量。

## 不要直接假设已经夺冠

比赛强度取决于正式地图、对手策略和真实 SDK 数据结构。尤其是 `calib` 的字段形状、owner/contour 空值编码、`game.copy().step()` 的副作用，需要用官方材料包确认。当前单元测试只验证本工程的几何与策略基础逻辑，不等于官方引擎一致性测试。

## 多种子回归（Windows PowerShell）

工程内提供 `tools/run_sweep.ps1`，在官方 `team121` Bot 已放入材料包且注册成功后执行：

```powershell
.\tools\run_sweep.ps1 -PlayerKitPath "D:\hackathon\player-kit" -StartSeed 1 -Count 30
```

它会先跑官方 `unittest`，再对每个 seed 分别测试 team121 在 0 号和 1 号位置对战 bot002，并保存日志。注意：这只是基准回归，不能代替与其他队伍的对抗测试。
