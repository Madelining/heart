# Strategy design notes

## Decision pipeline

```text
TurnState
  ├─ validate current beam / cooldown
  ├─ align any previously issued macro plan
  ├─ if on friendly territory:
  │    ├─ orientation-aware BFS inside friendly territory
  │    ├─ enumerate territory-anchored rectangular loops
  │    ├─ estimate gain = new value + enemy value removed - exposure delta
  │    ├─ penalize travel time and enemy access to exposed contour
  │    └─ keep the best bounded candidate set
  ├─ validate next command with game.copy().step() when available
  ├─ if outside territory: BFS back to friendly territory
  └─ otherwise choose the safest legal one-ply command
```

## Important rule handling

- A command opposite to the current heading does not turn the beam around; it keeps the previous direction.
- Speed is determined at the beginning of a turn. A boost cell can cause two substeps in the same direction. The path compiler rejects a route that would need to turn between those substeps.
- A rectangle is considered only when its base segment is already fully owned by the bot and the three exposed sides can be traversed without crossing defects or existing contours.
- A planned loop is stored across turns. The next call checks the actual beam position and heading against the predicted state. Any divergence invalidates the plan instead of blindly continuing stale commands.
- The one-ply simulator probe is a conservative filter, not a full opponent search. It only checks five likely enemy responses and cannot guarantee survival against arbitrary future play.

## Known limitations to resolve with the real kit

1. Validate exact `owner` and `contour` sentinel values and whether either matrix uses row strings rather than numeric cells.
2. Validate the actual `calib` representation. The code accepts a sequence of `(x, y)` centers or objects with `x`/`y`; if the SDK exposes rectangles or another representation, adjust `_calibration_cells`.
3. Confirm the official `Beam.dir` encoding. The adapter accepts `U/D/L/R` and common integer values, but enum encodings should be checked against `sdk/python/state.py`.
4. Confirm whether `Game.step([cmd0, cmd1])` mutates the copied game and whether `score(seat)` is callable on the copy.
5. Add replay-based tournament tests and profile worst-case action latency on the actual judging machine.
6. This first implementation focuses on rectangle closures. It does not yet implement minimax search, learned opponent models, or a complete response to complex irregular regions.
